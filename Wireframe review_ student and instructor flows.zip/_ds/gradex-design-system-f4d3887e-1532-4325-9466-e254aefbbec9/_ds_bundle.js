/* @ds-bundle: {"format":4,"namespace":"GradexDesignSystem_f4d388","components":[{"name":"BirdMark","sourcePath":"components/brand/BirdMark.jsx"},{"name":"CircleSketch","sourcePath":"components/brand/CircleSketch.jsx"},{"name":"Icon","sourcePath":"components/brand/Icon.jsx"},{"name":"Reveal","sourcePath":"components/brand/Reveal.jsx"},{"name":"Scribble","sourcePath":"components/brand/Scribble.jsx"},{"name":"Wordmark","sourcePath":"components/brand/Wordmark.jsx"},{"name":"Button","sourcePath":"components/buttons/Button.jsx"},{"name":"IconButton","sourcePath":"components/buttons/IconButton.jsx"},{"name":"Avatar","sourcePath":"components/display/Avatar.jsx"},{"name":"Badge","sourcePath":"components/display/Badge.jsx"},{"name":"Card","sourcePath":"components/display/Card.jsx"},{"name":"CourseCard","sourcePath":"components/display/CourseCard.jsx"},{"name":"ProgressBar","sourcePath":"components/display/ProgressBar.jsx"},{"name":"Tabs","sourcePath":"components/display/Tabs.jsx"},{"name":"Tag","sourcePath":"components/display/Tag.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"}],"sourceHashes":{"components/brand/BirdMark.jsx":"42af9c55b764","components/brand/CircleSketch.jsx":"0a1f39655e78","components/brand/Icon.jsx":"eabd916c71c7","components/brand/Reveal.jsx":"4c550df970f0","components/brand/Scribble.jsx":"bfc94fbfa455","components/brand/Wordmark.jsx":"9ee554315a25","components/buttons/Button.jsx":"24291442d1a1","components/buttons/IconButton.jsx":"680ac6e1cb7a","components/display/Avatar.jsx":"69edcd7c8a69","components/display/Badge.jsx":"16d14f96f605","components/display/Card.jsx":"02e153ce3963","components/display/CourseCard.jsx":"76844c441bf1","components/display/ProgressBar.jsx":"34d6d2924b25","components/display/Tabs.jsx":"259dc1385c82","components/display/Tag.jsx":"cb4bf6da7aeb","components/feedback/Dialog.jsx":"7c677c8a6854","components/feedback/Toast.jsx":"9039026406c3","components/feedback/Tooltip.jsx":"930a8bf6d67f","components/forms/Checkbox.jsx":"39e93994be9d","components/forms/Input.jsx":"151c00b8148f","components/forms/Radio.jsx":"51358c9fe257","components/forms/Select.jsx":"e58b10d5b84d","components/forms/Switch.jsx":"6e4088a9c2bf","ui_kits/website/LoginScreen.jsx":"1bebf03e6f41","ui_kits/website/copy.js":"71ba955b8b1a","ui_kits/website/sections.jsx":"bbad0ce815f7","ui_kits/website/visuals.jsx":"e4313f96e8f5"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.GradexDesignSystem_f4d388 = window.GradexDesignSystem_f4d388 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/BirdMark.jsx
try { (() => {
// Origami bird mark — current blue/orange palette (geometry from repo assets/logo.svg)
function BirdMark({
  size = 30,
  style
}) {
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size * 0.75,
    viewBox: "0 0 96 72",
    "aria-hidden": "true",
    style: {
      display: "block",
      flexShrink: 0,
      ...style
    }
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "gxBirdBody",
    x1: "0",
    y1: "0",
    x2: "1",
    y2: "1"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0",
    stopColor: "#4f7cff"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "1",
    stopColor: "#1e4ed8"
  })), /*#__PURE__*/React.createElement("linearGradient", {
    id: "gxBirdWing",
    x1: "0",
    y1: "0",
    x2: "1",
    y2: "1"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0",
    stopColor: "#7fa2ff"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "1",
    stopColor: "#4f7cff"
  }))), /*#__PURE__*/React.createElement("polygon", {
    points: "26,4 60,16 38,42",
    fill: "url(#gxBirdWing)"
  }), /*#__PURE__*/React.createElement("polygon", {
    points: "60,16 49,31 38,42",
    fill: "#16339e"
  }), /*#__PURE__*/React.createElement("polygon", {
    points: "60,16 76,25 66,31 55,28",
    fill: "#7fa2ff"
  }), /*#__PURE__*/React.createElement("polygon", {
    points: "76,25 90,23 79,32",
    fill: "#ff7e4d"
  }), /*#__PURE__*/React.createElement("polygon", {
    points: "38,42 58,29 76,38 55,53",
    fill: "url(#gxBirdBody)"
  }), /*#__PURE__*/React.createElement("polygon", {
    points: "38,42 20,52 42,49",
    fill: "#16339e"
  }), /*#__PURE__*/React.createElement("polygon", {
    points: "42,49 64,45 50,62",
    fill: "#1e4ed8"
  }));
}
Object.assign(__ds_scope, { BirdMark });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/BirdMark.jsx", error: String((e && e.message) || e) }); }

// components/brand/CircleSketch.jsx
try { (() => {
// Hand-drawn circle around a word — orange accent gradient
function CircleSketch({
  children
}) {
  const id = React.useId ? React.useId().replace(/:/g, "") : "gxc";
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-block"
    }
  }, children, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 120 44",
    preserveAspectRatio: "none",
    "aria-hidden": "true",
    style: {
      position: "absolute",
      inset: "-0.35em -0.7em",
      width: "calc(100% + 1.4em)",
      height: "calc(100% + 0.7em)",
      overflow: "visible",
      pointerEvents: "none"
    }
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: id,
    x1: "0",
    y1: "0",
    x2: "1",
    y2: "0"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0",
    stopColor: "#f64a1f"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "1",
    stopColor: "#ff7e4d"
  }))), /*#__PURE__*/React.createElement("path", {
    d: "M18 8 C 48 -2, 108 2, 113 18 C 117 34, 78 43, 40 40 C 12 38, 2 28, 10 15 C 14 8, 28 4, 44 4",
    fill: "none",
    stroke: `url(#${id})`,
    strokeWidth: "2.6",
    strokeLinecap: "round"
  })));
}
Object.assign(__ds_scope, { CircleSketch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/CircleSketch.jsx", error: String((e && e.message) || e) }); }

// components/brand/Icon.jsx
try { (() => {
// Lucide icons, inlined from the repo (stroke currentColor, 2px, round caps/joins)
const P = (d, i) => /*#__PURE__*/React.createElement("path", {
  key: i,
  d: d
});
const paths = {
  play: [],
  // handled below (polygon)
  shield: ["M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z", "m9 12 2 2 4-4"],
  fileText: ["M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z", "M14 2v4a2 2 0 0 0 2 2h4", "M16 13H8", "M16 17H8", "M10 9H8"],
  listChecks: ["m3 17 2 2 4-4", "m3 7 2 2 4-4", "M13 6h8", "M13 12h8", "M13 18h8"],
  languages: ["m5 8 6 6", "m4 14 6-6 2-3", "M2 5h12", "M7 2h1", "m22 22-5-10-5 10", "M14 18h6"],
  smartphone: [],
  users: ["M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", "M22 21v-2a4 4 0 0 0-3-3.87", "M16 3.13a4 4 0 0 1 0 7.75"],
  check: ["M20 6 9 17l-5-5"],
  bell: ["M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9", "M10.3 21a1.94 1.94 0 0 0 3.4 0"],
  arrowRight: ["M5 12h14", "m12 5 7 7-7 7"],
  gradCap: ["M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z", "M22 10v6", "M6 12.5V16a6 3 0 0 0 12 0v-3.5"],
  monitorPlay: ["M10 7.75a.75.75 0 0 1 1.142-.638l3.664 2.249a.75.75 0 0 1 0 1.278l-3.664 2.25a.75.75 0 0 1-1.142-.64z", "M12 17v4", "M8 21h8"],
  banknote: ["M6 12h.01M18 12h.01"],
  x: ["M18 6 6 18", "m6 6 12 12"],
  search: ["m21 21-4.34-4.34"],
  bookOpen: ["M12 7v14", "M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z"],
  clock: ["M12 6v6l4 2"]
};
const extras = {
  play: /*#__PURE__*/React.createElement("polygon", {
    points: "6 3 20 12 6 21 6 3"
  }),
  smartphone: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
    width: "14",
    height: "20",
    x: "5",
    y: "2",
    rx: "2",
    ry: "2"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 18h.01"
  })),
  banknote: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
    width: "20",
    height: "12",
    x: "2",
    y: "6",
    rx: "2"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "2"
  })),
  users: /*#__PURE__*/React.createElement("circle", {
    cx: "9",
    cy: "7",
    r: "4"
  }),
  monitorPlay: /*#__PURE__*/React.createElement("rect", {
    x: "2",
    y: "3",
    width: "20",
    height: "14",
    rx: "2"
  }),
  search: /*#__PURE__*/React.createElement("circle", {
    cx: "11",
    cy: "11",
    r: "8"
  }),
  clock: /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "10"
  })
};
function Icon({
  name,
  size = 20,
  style,
  className = ""
}) {
  const d = paths[name];
  if (!d && !extras[name]) return null;
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    className: className,
    style: {
      flexShrink: 0,
      ...style
    },
    "aria-hidden": "true"
  }, (d || []).map(P), extras[name] || null);
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Icon.jsx", error: String((e && e.message) || e) }); }

// components/brand/Reveal.jsx
try { (() => {
// Scroll-reveal wrapper: fades + rises 18px when scrolled into view (threshold 0.15). Respects prefers-reduced-motion via .gx-reveal CSS.
function Reveal({
  children,
  delay = 0,
  style = {},
  className = ""
}) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          el.classList.add("gx-in");
          io.disconnect();
        }
      });
    }, {
      threshold: 0.15
    });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    className: "gx-reveal " + className,
    style: {
      transitionDelay: delay + "ms",
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Reveal });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Reveal.jsx", error: String((e && e.message) || e) }); }

// components/brand/Scribble.jsx
try { (() => {
// Hand-drawn underline on one word of a heading — orange accent gradient, self-contained defs
function Scribble({
  children
}) {
  const id = React.useId ? React.useId().replace(/:/g, "") : "gxs";
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-block",
      whiteSpace: "nowrap"
    }
  }, children, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 100 12",
    preserveAspectRatio: "none",
    "aria-hidden": "true",
    style: {
      position: "absolute",
      left: 0,
      right: 0,
      bottom: "-0.18em",
      width: "100%",
      height: "0.22em",
      overflow: "visible",
      pointerEvents: "none"
    }
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: id,
    x1: "0",
    y1: "0",
    x2: "1",
    y2: "0"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0",
    stopColor: "#f64a1f"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "1",
    stopColor: "#ff7e4d"
  }))), /*#__PURE__*/React.createElement("path", {
    d: "M3 8 C 22 3, 42 10, 62 5 S 92 7, 97 4",
    fill: "none",
    stroke: `url(#${id})`,
    strokeWidth: "3.4",
    strokeLinecap: "round"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M6 10 C 30 6, 55 11, 96 6",
    fill: "none",
    stroke: `url(#${id})`,
    strokeWidth: "1.6",
    strokeLinecap: "round",
    opacity: "0.5"
  })));
}
Object.assign(__ds_scope, { Scribble });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Scribble.jsx", error: String((e && e.message) || e) }); }

// components/brand/Wordmark.jsx
try { (() => {
// Text wordmark: "Grade" in ink + "x" in orange accent. Always LTR.
function Wordmark({
  size = 26,
  inverse = false
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 800,
      fontSize: size,
      lineHeight: 1,
      letterSpacing: "-0.01em",
      color: inverse ? "#fff" : "var(--gradex-ink)",
      direction: "ltr",
      display: "inline-block",
      unicodeBidi: "isolate"
    }
  }, "Grade", /*#__PURE__*/React.createElement("span", {
    style: {
      color: inverse ? "var(--orange-200)" : "var(--accent)"
    }
  }, "x"));
}
Object.assign(__ds_scope, { Wordmark });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Wordmark.jsx", error: String((e && e.message) || e) }); }

// components/buttons/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// Values from repo docs/design-system.md §5.1
const variants = {
  primary: {
    bg: "var(--action-primary)",
    hoverBg: "var(--action-primary-hover)",
    color: "#fff",
    border: "1px solid transparent",
    hoverShadow: "var(--shadow-brand)"
  },
  secondary: {
    bg: "var(--accent)",
    hoverBg: "var(--accent-hover)",
    color: "#fff",
    border: "1px solid transparent",
    hoverShadow: "var(--shadow-sm)"
  },
  outline: {
    bg: "var(--surface-card)",
    hoverBg: "var(--blue-50)",
    color: "var(--ink-800)",
    hoverColor: "var(--blue-600)",
    border: "1px solid var(--border-default)"
  },
  ghost: {
    bg: "transparent",
    hoverBg: "var(--blue-50)",
    color: "var(--ink-800)",
    border: "1px solid transparent"
  }
};
const sizes = {
  sm: {
    padding: "8px 16px",
    fontSize: 12
  },
  md: {
    padding: "10px 20px",
    fontSize: 14
  },
  lg: {
    padding: "12px 24px",
    fontSize: 16
  }
};
function Button({
  variant = "primary",
  size = "md",
  icon,
  children,
  style,
  disabled,
  ...props
}) {
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const v = variants[variant] || variants.primary;
  const s = sizes[size] || sizes.md;
  return /*#__PURE__*/React.createElement("button", _extends({
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false),
    disabled: disabled,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      gap: 8,
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: s.fontSize,
      padding: s.padding,
      borderRadius: "var(--radius-lg)",
      border: v.border,
      cursor: disabled ? "not-allowed" : "pointer",
      background: hover && !disabled ? v.hoverBg : v.bg,
      color: hover && v.hoverColor && !disabled ? v.hoverColor : v.color,
      boxShadow: hover && v.hoverShadow && !disabled ? v.hoverShadow : "none",
      transform: active && !disabled ? "scale(0.98)" : "none",
      opacity: disabled ? 0.5 : 1,
      userSelect: "none",
      transition: "all var(--duration-base) var(--ease-out)",
      ...style
    }
  }, props), icon, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/Button.jsx", error: String((e && e.message) || e) }); }

// components/buttons/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const sizes = {
  sm: 32,
  md: 38,
  lg: 44
};
const variants = {
  primary: {
    bg: "var(--action-primary)",
    hoverBg: "var(--action-primary-hover)",
    color: "#fff",
    border: "1px solid transparent"
  },
  outline: {
    bg: "var(--surface-card)",
    hoverBg: "var(--blue-50)",
    color: "var(--ink-800)",
    border: "1px solid var(--border-default)"
  },
  ghost: {
    bg: "transparent",
    hoverBg: "var(--blue-50)",
    color: "var(--ink-800)",
    border: "1px solid transparent"
  }
};
function IconButton({
  variant = "ghost",
  size = "md",
  label,
  children,
  style,
  disabled,
  ...props
}) {
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const v = variants[variant] || variants.ghost;
  const px = sizes[size] || sizes.md;
  return /*#__PURE__*/React.createElement("button", _extends({
    "aria-label": label,
    title: label,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false),
    disabled: disabled,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: px,
      height: px,
      borderRadius: "var(--radius-md)",
      border: v.border,
      background: hover && !disabled ? v.hoverBg : v.bg,
      color: v.color,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      transform: active && !disabled ? "scale(0.98)" : "none",
      transition: "all var(--duration-base) var(--ease-out)",
      ...style
    }
  }, props), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/display/Avatar.jsx
try { (() => {
function Avatar({
  initials,
  size = 46,
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      width: size,
      height: size,
      borderRadius: "50%",
      background: "var(--blue-500)",
      color: "#fff",
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: Math.round(size * 0.33),
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0,
      ...style
    }
  }, initials);
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/display/Badge.jsx
try { (() => {
const tones = {
  brand: {
    bg: "var(--blue-50)",
    color: "var(--blue-600)",
    border: "1px solid var(--blue-100)"
  },
  warning: {
    bg: "var(--warning-soft)",
    color: "var(--warning)",
    border: "1px solid #f5deb8"
  },
  neutral: {
    bg: "var(--ink-50)",
    color: "var(--ink-700)",
    border: "1px solid var(--ink-200)"
  }
};
function Badge({
  tone = "brand",
  children,
  style
}) {
  const t = tones[tone] || tones.brand;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      padding: "4px 10px",
      borderRadius: "var(--radius-pill)",
      background: t.bg,
      color: t.color,
      border: t.border,
      fontFamily: "var(--font-display)",
      fontWeight: 600,
      fontSize: 12,
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/display/Card.jsx
try { (() => {
function Card({
  padding = 24,
  hoverable = false,
  className = "",
  children,
  style
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      background: "var(--surface-card)",
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-lg)",
      boxShadow: hoverable && hover ? "var(--shadow-md)" : "var(--shadow-sm)",
      transform: hoverable && hover ? "translateY(-2px)" : "none",
      transition: "all var(--duration-base) var(--ease-out)",
      padding,
      boxSizing: "border-box",
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Card.jsx", error: String((e && e.message) || e) }); }

// components/display/ProgressBar.jsx
try { (() => {
function ProgressBar({
  value = 0,
  gradient = false,
  showLabel = false,
  height = 8
}) {
  const v = Math.max(0, Math.min(100, value));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      width: "100%"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height,
      borderRadius: "var(--radius-pill)",
      overflow: "hidden",
      background: "var(--ink-100)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: v + "%",
      height: "100%",
      borderRadius: "var(--radius-pill)",
      background: gradient ? "var(--gradient-brand)" : "var(--action-primary)",
      transition: "width 500ms var(--ease-out)"
    }
  })), showLabel && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: 12,
      color: "var(--ink-600)",
      minWidth: 34,
      textAlign: "end"
    }
  }, v, "%"));
}
Object.assign(__ds_scope, { ProgressBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/ProgressBar.jsx", error: String((e && e.message) || e) }); }

// components/display/CourseCard.jsx
try { (() => {
// Course tile — header band tones from repo docs/design-system.md §5.4
const tones = {
  blue: "linear-gradient(135deg, #1b4fd8, #4e85f6)",
  purple: "linear-gradient(135deg, #6425c9, #915fef)",
  brand: "var(--gradient-brand)",
  navy: "linear-gradient(135deg, #12123b, #34345e)"
};
function CourseCard({
  code,
  title,
  notesCount,
  progress,
  tone = "blue",
  dir = "ltr",
  onClick,
  style
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    dir: dir,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: 280,
      background: "#fff",
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-lg)",
      overflow: "hidden",
      cursor: onClick ? "pointer" : "default",
      userSelect: "none",
      boxShadow: hover ? "var(--shadow-lg)" : "var(--shadow-sm)",
      transform: hover ? "translateY(-2px)" : "none",
      transition: "all var(--duration-base) var(--ease-out)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 88,
      display: "flex",
      alignItems: "flex-end",
      padding: 14,
      boxSizing: "border-box",
      background: tones[tone] || tones.blue
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 12,
      fontWeight: 600,
      color: "rgba(255,255,255,0.95)",
      background: "rgba(255,255,255,0.15)",
      padding: "2px 10px",
      borderRadius: "var(--radius-pill)",
      direction: "ltr"
    }
  }, code)), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 16,
      display: "flex",
      flexDirection: "column",
      gap: 10,
      textAlign: "start"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: 16,
      color: "var(--text-heading)",
      lineHeight: 1.35
    }
  }, title), notesCount != null && /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "neutral"
  }, notesCount, " notes")), progress != null && /*#__PURE__*/React.createElement(__ds_scope.ProgressBar, {
    value: progress,
    showLabel: true
  })));
}
Object.assign(__ds_scope, { CourseCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/CourseCard.jsx", error: String((e && e.message) || e) }); }

// components/display/Tabs.jsx
try { (() => {
function Tabs({
  items = [],
  value,
  onChange,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    role: "tablist",
    style: {
      display: "flex",
      gap: 4,
      borderBottom: "1px solid var(--border-default)",
      ...style
    }
  }, items.map(it => {
    const active = it.value === value;
    return /*#__PURE__*/React.createElement("button", {
      key: it.value,
      role: "tab",
      "aria-selected": active,
      onClick: () => onChange && onChange(it.value),
      style: {
        padding: "10px 16px",
        background: "none",
        border: "none",
        cursor: "pointer",
        fontFamily: "var(--font-display)",
        fontWeight: 700,
        fontSize: 14,
        color: active ? "var(--blue-600)" : "var(--ink-600)",
        borderBottom: active ? "2px solid var(--blue-500)" : "2px solid transparent",
        marginBottom: -1,
        transition: "color var(--duration-fast) var(--ease-out)"
      }
    }, it.label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/display/Tag.jsx
try { (() => {
// Inline label tag — squarer and quieter than Badge
function Tag({
  children,
  mono = false,
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 4,
      padding: "3px 8px",
      borderRadius: "var(--radius-sm)",
      background: "var(--ink-100)",
      color: "var(--ink-700)",
      fontFamily: mono ? "var(--font-mono)" : "var(--font-display)",
      fontWeight: 600,
      fontSize: 12,
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function Dialog({
  open,
  onClose,
  title,
  children,
  footer,
  width = 480
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 100,
      background: "rgba(13,27,42,0.5)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-modal": "true",
    onClick: e => e.stopPropagation(),
    style: {
      width: "100%",
      maxWidth: width,
      background: "var(--surface-card)",
      borderRadius: "var(--radius-xl)",
      boxShadow: "var(--shadow-lg)",
      padding: 28,
      boxSizing: "border-box"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 16,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: 19,
      color: "var(--text-heading)"
    }
  }, title), /*#__PURE__*/React.createElement("button", {
    "aria-label": "Close",
    onClick: onClose,
    style: {
      width: 32,
      height: 32,
      borderRadius: "var(--radius-md)",
      border: "none",
      background: "transparent",
      cursor: "pointer",
      color: "var(--ink-500)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M18 6 6 18"
  }), /*#__PURE__*/React.createElement("path", {
    d: "m6 6 12 12"
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: 15,
      color: "var(--text-body)",
      lineHeight: 1.6
    }
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "flex-end",
      gap: 10,
      marginTop: 24
    }
  }, footer)));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
const tones = {
  info: {
    border: "var(--blue-100)",
    icon: "var(--blue-500)"
  },
  success: {
    border: "#cdebd9",
    icon: "var(--success)"
  },
  danger: {
    border: "#f6cfc5",
    icon: "var(--danger)"
  }
};
function Toast({
  open = true,
  tone = "info",
  children,
  style
}) {
  if (!open) return null;
  const t = tones[tone] || tones.info;
  return /*#__PURE__*/React.createElement("div", {
    role: "status",
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 10,
      padding: "12px 18px",
      background: "var(--surface-card)",
      border: "1px solid " + t.border,
      borderRadius: "var(--radius-md)",
      boxShadow: "var(--shadow-lg)",
      fontFamily: "var(--font-display)",
      fontWeight: 600,
      fontSize: 14,
      color: "var(--ink-800)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: "50%",
      background: t.icon,
      flexShrink: 0
    }
  }), children);
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function Tooltip({
  label,
  children,
  style
}) {
  const [show, setShow] = React.useState(false);
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-flex",
      ...style
    },
    onMouseEnter: () => setShow(true),
    onMouseLeave: () => setShow(false),
    onFocus: () => setShow(true),
    onBlur: () => setShow(false)
  }, children, show && /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: "absolute",
      bottom: "calc(100% + 8px)",
      left: "50%",
      transform: "translateX(-50%)",
      background: "var(--ink-900)",
      color: "#fff",
      fontFamily: "var(--font-body)",
      fontSize: 12.5,
      padding: "6px 10px",
      borderRadius: "var(--radius-sm)",
      whiteSpace: "nowrap",
      boxShadow: "var(--shadow-md)",
      zIndex: 50,
      pointerEvents: "none"
    }
  }, label));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  label,
  checked,
  defaultChecked = false,
  onChange,
  disabled,
  style
}) {
  const [inner, setInner] = React.useState(defaultChecked);
  const isOn = checked != null ? checked : inner;
  const toggle = () => {
    if (disabled) return;
    if (checked == null) setInner(!isOn);
    onChange && onChange(!isOn);
  };
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 10,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      userSelect: "none",
      ...style
    },
    onClick: toggle
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      borderRadius: 5,
      flexShrink: 0,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      border: isOn ? "none" : "2px solid var(--ink-300)",
      background: isOn ? "var(--blue-500)" : "#fff",
      transition: "all var(--duration-fast) var(--ease-out)",
      boxSizing: "border-box"
    }
  }, isOn && /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "#fff",
    strokeWidth: "3",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M20 6 9 17l-5-5"
  }))), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: 15,
      color: "var(--ink-800)"
    }
  }, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  label,
  style,
  inputStyle,
  ...props
}) {
  const [focus, setFocus] = React.useState(false);
  const field = /*#__PURE__*/React.createElement("input", _extends({
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      height: 42,
      padding: "0 16px",
      minWidth: 220,
      boxSizing: "border-box",
      border: "1px solid " + (focus ? "var(--border-focus)" : "var(--border-default)"),
      borderRadius: "var(--radius-md)",
      background: "#fff",
      fontFamily: "var(--font-body)",
      fontSize: 15,
      color: "var(--ink-800)",
      outline: "none",
      boxShadow: focus ? "var(--ring-focus)" : "none",
      transition: "box-shadow var(--duration-fast) var(--ease-out), border-color var(--duration-fast) var(--ease-out)",
      ...inputStyle
    }
  }, props));
  if (!label) return field;
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 600,
      fontSize: 13.5,
      color: "var(--ink-700)"
    }
  }, label), field);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function Radio({
  label,
  checked = false,
  onChange,
  disabled,
  name,
  style
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 10,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      userSelect: "none",
      ...style
    },
    onClick: () => !disabled && onChange && onChange()
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      borderRadius: "50%",
      flexShrink: 0,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      border: checked ? "2px solid var(--blue-500)" : "2px solid var(--ink-300)",
      background: "#fff",
      transition: "all var(--duration-fast) var(--ease-out)",
      boxSizing: "border-box"
    }
  }, checked && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: "50%",
      background: "var(--blue-500)"
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: 15,
      color: "var(--ink-800)"
    }
  }, label), name ? /*#__PURE__*/React.createElement("input", {
    type: "radio",
    name: name,
    checked: checked,
    readOnly: true,
    style: {
      display: "none"
    }
  }) : null);
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  label,
  options = [],
  style,
  selectStyle,
  ...props
}) {
  const [focus, setFocus] = React.useState(false);
  const field = /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-flex",
      minWidth: 220
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      height: 42,
      padding: "0 36px 0 16px",
      width: "100%",
      appearance: "none",
      boxSizing: "border-box",
      border: "1px solid " + (focus ? "var(--border-focus)" : "var(--border-default)"),
      borderRadius: "var(--radius-md)",
      background: "#fff",
      fontFamily: "var(--font-body)",
      fontSize: 15,
      color: "var(--ink-800)",
      outline: "none",
      cursor: "pointer",
      boxShadow: focus ? "var(--ring-focus)" : "none",
      transition: "box-shadow var(--duration-fast) var(--ease-out), border-color var(--duration-fast) var(--ease-out)",
      ...selectStyle
    }
  }, props), options.map(o => /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label))), /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--ink-500)",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      position: "absolute",
      insetInlineEnd: 12,
      top: 13,
      pointerEvents: "none"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "m6 9 6 6 6-6"
  })));
  if (!label) return field;
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 600,
      fontSize: 13.5,
      color: "var(--ink-700)"
    }
  }, label), field);
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function Switch({
  label,
  checked,
  defaultChecked = false,
  onChange,
  disabled,
  style
}) {
  const [inner, setInner] = React.useState(defaultChecked);
  const isOn = checked != null ? checked : inner;
  const toggle = () => {
    if (disabled) return;
    if (checked == null) setInner(!isOn);
    onChange && onChange(!isOn);
  };
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 10,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      userSelect: "none",
      ...style
    },
    onClick: toggle
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 22,
      borderRadius: "var(--radius-pill)",
      background: isOn ? "var(--blue-500)" : "var(--ink-300)",
      position: "relative",
      flexShrink: 0,
      transition: "background var(--duration-base) var(--ease-out)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 2,
      insetInlineStart: isOn ? 20 : 2,
      width: 18,
      height: 18,
      borderRadius: "50%",
      background: "#fff",
      boxShadow: "var(--shadow-sm)",
      transition: "inset-inline-start var(--duration-base) var(--ease-out)"
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: 15,
      color: "var(--ink-800)"
    }
  }, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/LoginScreen.jsx
try { (() => {
// Login screen — Gradex auth surface
const {
  BirdMark: LBird,
  Wordmark: LWord,
  Icon: LIcon,
  Button: LButton,
  Input: LInput,
  Checkbox: LCheckbox
} = window.GradexDesignSystem_f4d388;
function LoginScreen({
  t,
  onBack,
  onLang,
  langLabel
}) {
  const [sent, setSent] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: "100vh",
      display: "grid",
      gridTemplateColumns: "1fr 1fr"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--ink-900)",
      position: "relative",
      overflow: "hidden",
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between",
      padding: 48,
      boxSizing: "border-box"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      background: "radial-gradient(700px 480px at 30% 30%, rgba(79,124,255,0.3), transparent 65%)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-flex",
      alignItems: "center",
      gap: 9
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-bird.png",
    alt: "",
    style: {
      height: 32,
      display: "block"
    }
  }), /*#__PURE__*/React.createElement(LWord, {
    size: 21,
    inverse: true
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "flex",
      flexDirection: "column",
      gap: 14,
      paddingBottom: 24
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 800,
      fontSize: "clamp(30px,3vw,42px)",
      color: "#fff",
      lineHeight: 1.2,
      textWrap: "balance"
    }
  }, t.hero.title), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: 16,
      color: "rgba(255,255,255,0.65)",
      maxWidth: 380,
      lineHeight: 1.7
    }
  }, t.hero.sub))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-page)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 32
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "100%",
      maxWidth: 400,
      background: "var(--surface-card)",
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-xl)",
      boxShadow: "var(--shadow-md)",
      padding: 36,
      boxSizing: "border-box",
      display: "flex",
      flexDirection: "column",
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onBack();
    },
    style: {
      fontFamily: "var(--font-body)",
      fontSize: 13.5
    }
  }, t.login.back), /*#__PURE__*/React.createElement(LButton, {
    variant: "outline",
    size: "sm",
    onClick: onLang
  }, langLabel)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 800,
      fontSize: 26,
      color: "var(--text-heading)"
    }
  }, t.login.title), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: 14.5,
      color: "var(--ink-500)"
    }
  }, t.login.sub)), sent ? /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--success-soft)",
      color: "var(--success)",
      borderRadius: "var(--radius-md)",
      padding: "14px 18px",
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: 14.5
    }
  }, "\u2713 ", t.login.title) : /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      setSent(true);
    },
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(LInput, {
    label: t.login.email,
    type: "email",
    required: true,
    inputStyle: {
      minWidth: 0,
      width: "100%"
    }
  }), /*#__PURE__*/React.createElement(LInput, {
    label: t.login.password,
    type: "password",
    required: true,
    inputStyle: {
      minWidth: 0,
      width: "100%"
    }
  }), /*#__PURE__*/React.createElement(LCheckbox, {
    label: t.login.remember,
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(LButton, {
    variant: "primary",
    size: "lg",
    type: "submit",
    style: {
      width: "100%"
    }
  }, t.login.submit)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: 13.5,
      color: "var(--ink-500)",
      textAlign: "center"
    }
  }, t.login.alt, " ", /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, t.login.altCta)))));
}
window.LoginScreen = LoginScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/LoginScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/copy.js
try { (() => {
// Gradex landing + auth — bilingual copy (from repo landing/copy.jsx + messages/*.json)
const GRADEX_COPY = {
  en: {
    dir: "ltr",
    nav: {
      links: [{
        label: "Courses",
        href: "#courses"
      }, {
        label: "Features",
        href: "#features"
      }, {
        label: "For instructors",
        href: "#instructors"
      }],
      signIn: "Sign in",
      cta: "Browse courses",
      langSwitch: "عربي"
    },
    hero: {
      badge: "Now launching in Kuwait",
      title: "Graduate with excellence.",
      sub: "University courses and study notes, made for GCC students.",
      ctaPrimary: "Browse courses",
      ctaSecondary: "Become an instructor"
    },
    features: {
      eyebrow: "Why Gradex",
      title: "Everything you need to pass — and to excel",
      rows: [{
        key: "stream",
        eyebrow: "Secure streaming",
        title: "Lectures that stream anywhere",
        desc: "Adaptive video that follows your connection, with session-based watermarking so course content stays protected.",
        bullets: ["Works on any device, any speed", "Dynamic watermark on every session", "Resume exactly where you left off"]
      }, {
        key: "notes",
        eyebrow: "Study notes",
        title: "Notes that get to the point",
        desc: "Every course ships with concise chapter summaries — review a whole chapter in minutes before the exam.",
        bullets: ["Written per chapter, not per slide", "Key terms and formulas highlighted", "Download and study offline"]
      }, {
        key: "quiz",
        eyebrow: "Interactive quizzes",
        title: "Check yourself after every lesson",
        desc: "Short quizzes at the end of each lesson show you what stuck — and what needs another pass.",
        bullets: ["Instant feedback per question", "Track your score per chapter", "Retake as many times as you need"]
      }],
      grid: [{
        key: "bilingual",
        title: "Arabic first, English ready",
        desc: "The whole platform mirrors cleanly between Arabic and English. Course content stays in English; everything else speaks your language."
      }, {
        key: "kwd",
        title: "Pay in dinars",
        desc: "Buy a full course, a single chapter, or a bundle — priced in KWD and paid through local payment methods."
      }, {
        key: "instructor",
        title: "Built for instructors too",
        desc: "Upload once — we handle transcoding, protection, quizzes, and analytics. Teaching tools that stay out of your way."
      }]
    },
    courses: {
      eyebrow: "Catalog",
      title: "Top courses this semester",
      cta: "View all courses",
      items: [{
        code: "CS 201",
        title: "Data structures",
        notes: 24,
        tone: "blue",
        meta: "38.000 KWD · 8 chapters"
      }, {
        code: "CS 305",
        title: "Algorithms",
        notes: 31,
        tone: "navy",
        meta: "42.000 KWD · 10 chapters"
      }, {
        code: "CS 220",
        title: "Database systems",
        notes: 18,
        tone: "purple",
        meta: "35.000 KWD · 7 chapters"
      }]
    },
    testimonials: {
      title: "What our students say",
      items: [{
        initials: "SA",
        name: "Sarah Al-Mansour",
        role: "Computer science student",
        quote: "Gradex completely changed how I learn algorithms. The concise notes and the Arabic support were game changers for me."
      }, {
        initials: "FA",
        name: "Fahad Al-Azmi",
        role: "Instructor · Software engineering",
        quote: "The instructor tools are incredible. I upload a lecture once and it comes out as a secure, watermarked stream — no extra work."
      }]
    },
    instructors: {
      eyebrow: "For instructors",
      title: "Teach on Gradex",
      desc: "Share your expertise with students across the GCC. Our team reviews applications within 3–5 business days.",
      cta: "Apply as an instructor"
    },
    app: {
      badge: "Coming soon",
      title: "Gradex is coming to your pocket",
      desc: "The Gradex mobile app — lectures, notes, and quizzes offline, on iOS and Android. Be the first to know.",
      inputPlaceholder: "Your email",
      button: "Notify me",
      done: "Done! We'll email you at launch.",
      platforms: "iOS · Android"
    },
    footer: {
      tagline: "Graduate with excellence.",
      columns: [{
        title: "Platform",
        links: ["Courses", "Study notes", "Certificates", "Verify a certificate"]
      }, {
        title: "Company",
        links: ["About", "Become an instructor", "Contact"]
      }, {
        title: "Legal",
        links: ["Terms", "Privacy"]
      }],
      copyright: "© 2026 Gradex. All rights reserved."
    },
    login: {
      title: "Welcome back",
      sub: "Sign in to continue studying",
      email: "Email",
      password: "Password",
      remember: "Remember me",
      submit: "Sign in",
      alt: "New to Gradex?",
      altCta: "Create an account",
      back: "← Back to home"
    },
    dialog: {
      buy: "Buy this course",
      checkout: "Checkout",
      cancel: "Cancel"
    }
  },
  ar: {
    dir: "rtl",
    nav: {
      links: [{
        label: "المقررات",
        href: "#courses"
      }, {
        label: "المميزات",
        href: "#features"
      }, {
        label: "للمدرّسين",
        href: "#instructors"
      }],
      signIn: "تسجيل الدخول",
      cta: "تصفح المقررات",
      langSwitch: "English"
    },
    hero: {
      badge: "نطلق الآن في الكويت",
      title: "تخرّج بتفوّق.",
      sub: "مقررات جامعية وملخصات دراسية، صُممت لطلبة الخليج.",
      ctaPrimary: "تصفح المقررات",
      ctaSecondary: "انضم كمدرّس"
    },
    features: {
      eyebrow: "لماذا Gradex",
      title: "كل ما تحتاجه لتنجح — وتتفوّق",
      rows: [{
        key: "stream",
        eyebrow: "بث آمن",
        title: "محاضرات تصلك أينما كنت",
        desc: "فيديو تكيّفي يناسب سرعة اتصالك، مع علامة مائية لكل جلسة لتبقى المحاضرات محمية.",
        bullets: ["يعمل على أي جهاز وأي سرعة", "علامة مائية ديناميكية لكل جلسة", "أكمل من حيث توقفت تماماً"]
      }, {
        key: "notes",
        eyebrow: "الملخصات",
        title: "ملخصات تختصر الطريق",
        desc: "كل مقرر يأتي مع ملخصات مركّزة لكل فصل — راجع الفصل كاملاً في دقائق قبل الاختبار.",
        bullets: ["مكتوبة لكل فصل، لا لكل شريحة", "المصطلحات والقوانين المهمة مميّزة", "حمّلها وذاكر دون اتصال"]
      }, {
        key: "quiz",
        eyebrow: "الاختبارات",
        title: "اختبر نفسك بعد كل درس",
        desc: "اختبارات قصيرة في نهاية كل درس تريك ما رسخ — وما يحتاج مراجعة أخرى.",
        bullets: ["نتيجة فورية لكل سؤال", "تابع درجاتك لكل فصل", "أعد المحاولة كما تشاء"]
      }],
      grid: [{
        key: "bilingual",
        title: "العربية أولاً، والإنجليزية جاهزة",
        desc: "المنصة كاملة تنعكس بسلاسة بين العربية والإنجليزية. محتوى المقررات يبقى بالإنجليزية، وكل ما عداه يتحدث لغتك."
      }, {
        key: "kwd",
        title: "ادفع بالدينار",
        desc: "اشترِ مقرراً كاملاً أو فصلاً واحداً أو حزمة — بأسعار بالدينار الكويتي وعبر وسائل دفع محلية."
      }, {
        key: "instructor",
        title: "صُمم للمدرّسين أيضاً",
        desc: "ارفع المحتوى مرة واحدة — ونتكفل بالمعالجة والحماية والاختبارات والتحليلات."
      }]
    },
    courses: {
      eyebrow: "الدليل",
      title: "أبرز مقررات هذا الفصل",
      cta: "عرض كل المقررات",
      items: [{
        code: "CS 201",
        title: "Data structures",
        notes: 24,
        tone: "blue",
        meta: "38.000 د.ك · 8 فصول"
      }, {
        code: "CS 305",
        title: "Algorithms",
        notes: 31,
        tone: "navy",
        meta: "42.000 د.ك · 10 فصول"
      }, {
        code: "CS 220",
        title: "Database systems",
        notes: 18,
        tone: "purple",
        meta: "35.000 د.ك · 7 فصول"
      }]
    },
    testimonials: {
      title: "ماذا يقول طلابنا",
      items: [{
        initials: "سم",
        name: "سارة المنصور",
        role: "طالبة علوم حاسوب",
        quote: "غيّرت Gradex طريقتي في فهم الخوارزميات. الملخصات المركّزة والدعم بالعربية فرقا معي كثيراً."
      }, {
        initials: "فع",
        name: "فهد العازمي",
        role: "مدرّس · هندسة برمجيات",
        quote: "أدوات المدرّس ممتازة. أرفع المحاضرة مرة واحدة وتخرج بثاً آمناً بعلامة مائية — دون أي جهد إضافي."
      }]
    },
    instructors: {
      eyebrow: "للمدرّسين",
      title: "درّس على Gradex",
      desc: "شارك خبرتك مع طلبة الخليج. يراجع فريقنا الطلبات خلال 3–5 أيام عمل.",
      cta: "قدّم كمدرّس"
    },
    app: {
      badge: "قريباً",
      title: "Gradex في جيبك قريباً",
      desc: "تطبيق Gradex — محاضرات وملخصات واختبارات دون اتصال، على iOS وAndroid. كن أول من يعلم.",
      inputPlaceholder: "بريدك الإلكتروني",
      button: "أعلمني",
      done: "تم! سنراسلك عند الإطلاق.",
      platforms: "iOS · Android"
    },
    footer: {
      tagline: "تخرّج بتفوّق.",
      columns: [{
        title: "المنصة",
        links: ["المقررات", "الملخصات", "الشهادات", "تحقق من شهادة"]
      }, {
        title: "الشركة",
        links: ["من نحن", "انضم كمدرّس", "تواصل معنا"]
      }, {
        title: "قانوني",
        links: ["الشروط", "الخصوصية"]
      }],
      copyright: "© 2026 Gradex. جميع الحقوق محفوظة."
    },
    login: {
      title: "أهلاً بعودتك",
      sub: "سجّل الدخول لتواصل الدراسة",
      email: "البريد الإلكتروني",
      password: "كلمة المرور",
      remember: "تذكرني",
      submit: "تسجيل الدخول",
      alt: "جديد على Gradex؟",
      altCta: "أنشئ حساباً",
      back: "→ العودة للرئيسية"
    },
    dialog: {
      buy: "اشترِ هذا المقرر",
      checkout: "إتمام الشراء",
      cancel: "إلغاء"
    }
  }
};
window.GRADEX_COPY = GRADEX_COPY;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/copy.js", error: String((e && e.message) || e) }); }

// ui_kits/website/sections.jsx
try { (() => {
// Gradex landing page sections — composes DS components; scroll cover-stack + reveals
const {
  BirdMark,
  Wordmark,
  Icon,
  Scribble,
  Reveal,
  Button,
  IconButton,
  Badge,
  CourseCard,
  Avatar,
  Input
} = window.GradexDesignSystem_f4d388;
function Nav({
  t,
  lang,
  onLang,
  onLogin
}) {
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      position: "fixed",
      top: 0,
      insetInline: 0,
      zIndex: 90,
      height: 64,
      background: "rgba(255,255,255,0.88)",
      backdropFilter: "blur(12px)",
      WebkitBackdropFilter: "blur(12px)",
      borderBottom: "1px solid var(--border-default)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "gx-container",
    style: {
      display: "flex",
      alignItems: "center",
      gap: 24,
      height: "100%"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#top",
    style: {
      display: "inline-flex",
      alignItems: "center",
      textDecoration: "none"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-full.png",
    alt: "Gradex",
    style: {
      height: 40,
      display: "block"
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 4,
      marginInlineStart: 12
    }
  }, t.nav.links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l.href,
    href: l.href,
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 600,
      fontSize: 14,
      color: "var(--ink-700)",
      padding: "8px 12px",
      borderRadius: "var(--radius-md)",
      textDecoration: "none"
    }
  }, l.label))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginInlineStart: "auto",
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    size: "sm",
    onClick: onLang
  }, t.nav.langSwitch), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    onClick: onLogin
  }, t.nav.signIn), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm"
  }, t.nav.cta))));
}
function Hero({
  t
}) {
  return /*#__PURE__*/React.createElement("section", {
    id: "top",
    style: {
      minHeight: "88vh",
      background: "var(--ink-900)",
      overflow: "hidden",
      display: "flex",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      background: "radial-gradient(900px 500px at 70% 20%, rgba(79,124,255,0.28), transparent 65%)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "gx-container",
    style: {
      position: "relative",
      display: "grid",
      gridTemplateColumns: "1.15fr 0.85fr",
      gap: 48,
      alignItems: "center",
      paddingTop: 96,
      paddingBottom: 64
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 22,
      alignItems: "flex-start"
    }
  }, /*#__PURE__*/React.createElement(Reveal, null, /*#__PURE__*/React.createElement(Badge, {
    tone: "warning"
  }, t.hero.badge)), /*#__PURE__*/React.createElement(Reveal, {
    delay: 90
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontWeight: 800,
      fontSize: "clamp(40px,5.4vw,64px)",
      lineHeight: 1.14,
      color: "#fff",
      textWrap: "balance"
    }
  }, t.hero.title)), /*#__PURE__*/React.createElement(Reveal, {
    delay: 180
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: "var(--font-body)",
      fontSize: 19,
      lineHeight: 1.7,
      color: "rgba(255,255,255,0.72)",
      maxWidth: 460
    }
  }, t.hero.sub)), /*#__PURE__*/React.createElement(Reveal, {
    delay: 270
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "arrowRight",
      size: 17,
      style: {
        transform: t.dir === "rtl" ? "scaleX(-1)" : "none"
      }
    })
  }, t.hero.ctaPrimary), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "lg",
    style: {
      color: "#fff"
    }
  }, t.hero.ctaSecondary)))), /*#__PURE__*/React.createElement(Reveal, {
    delay: 200
  }, /*#__PURE__*/React.createElement("div", {
    dir: "ltr"
  }, /*#__PURE__*/React.createElement(StreamMock, null)))));
}
function FeatureRow({
  row,
  i,
  lang
}) {
  const Mock = row.key === "stream" ? StreamMock : row.key === "notes" ? NotesMock : QuizMock;
  const flip = i % 2 === 1;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 56,
      alignItems: "center",
      direction: "inherit"
    }
  }, /*#__PURE__*/React.createElement(Reveal, {
    style: {
      order: flip ? 2 : 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14,
      alignItems: "flex-start"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "gx-eyebrow"
  }, row.eyebrow), /*#__PURE__*/React.createElement("h3", {
    className: "gx-h3",
    style: {
      margin: 0
    }
  }, row.title), /*#__PURE__*/React.createElement("p", {
    className: "gx-body",
    style: {
      margin: 0
    }
  }, row.desc), /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: 0,
      padding: 0,
      listStyle: "none",
      display: "flex",
      flexDirection: "column",
      gap: 9
    }
  }, row.bullets.map((b, j) => /*#__PURE__*/React.createElement("li", {
    key: j,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      fontFamily: "var(--font-body)",
      fontSize: 15.5,
      color: "var(--ink-700)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      borderRadius: "50%",
      background: "var(--blue-50)",
      color: "var(--blue-600)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 12
  })), b))))), /*#__PURE__*/React.createElement(Reveal, {
    delay: 120,
    style: {
      order: flip ? 1 : 2
    }
  }, /*#__PURE__*/React.createElement(Mock, {
    lang: lang
  })));
}
function Features({
  t,
  lang
}) {
  const gridIcons = {
    bilingual: "languages",
    kwd: "banknote",
    instructor: "users"
  };
  return /*#__PURE__*/React.createElement("section", {
    id: "features",
    style: {
      background: "var(--surface-page)",
      padding: "88px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "gx-container",
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 72
    }
  }, /*#__PURE__*/React.createElement(Reveal, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12,
      alignItems: "center",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "gx-eyebrow"
  }, t.features.eyebrow), /*#__PURE__*/React.createElement("h2", {
    className: "gx-h2",
    style: {
      margin: 0,
      maxWidth: 640
    }
  }, t.features.title))), t.features.rows.map((row, i) => /*#__PURE__*/React.createElement(FeatureRow, {
    key: row.key,
    row: row,
    i: i,
    lang: lang
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3,1fr)",
      gap: 20
    }
  }, t.features.grid.map((g, i) => /*#__PURE__*/React.createElement(Reveal, {
    key: g.key,
    delay: i * 90
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-card)",
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-lg)",
      padding: 26,
      height: "100%",
      boxSizing: "border-box",
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 42,
      height: 42,
      borderRadius: "var(--radius-md)",
      background: "var(--blue-50)",
      color: "var(--blue-600)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: gridIcons[g.key],
    size: 22
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: 17,
      color: "var(--text-heading)"
    }
  }, g.title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: "var(--font-body)",
      fontSize: 14.5,
      lineHeight: 1.65,
      color: "var(--ink-600)"
    }
  }, g.desc)))))));
}
function Courses({
  t,
  onBuy
}) {
  return /*#__PURE__*/React.createElement("section", {
    id: "courses",
    style: {
      background: "#fff",
      padding: "88px 0",
      borderBlock: "1px solid var(--border-default)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "gx-container",
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 40
    }
  }, /*#__PURE__*/React.createElement(Reveal, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      justifyContent: "space-between",
      gap: 20,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "gx-eyebrow"
  }, t.courses.eyebrow), /*#__PURE__*/React.createElement("h2", {
    className: "gx-h2",
    style: {
      margin: 0
    }
  }, t.courses.title)), /*#__PURE__*/React.createElement(Button, {
    variant: "outline"
  }, t.courses.cta))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 24,
      flexWrap: "wrap",
      justifyContent: "center"
    }
  }, t.courses.items.map((c, i) => /*#__PURE__*/React.createElement(Reveal, {
    key: c.code,
    delay: i * 90
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(CourseCard, {
    code: c.code,
    title: c.title,
    notesCount: c.notes,
    tone: c.tone,
    dir: t.dir,
    onClick: () => onBuy(c)
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: 13.5,
      color: "var(--ink-500)",
      paddingInlineStart: 4
    }
  }, c.meta)))))));
}
function Testimonials({
  t
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--surface-page)",
      padding: "88px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "gx-container",
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 36
    }
  }, /*#__PURE__*/React.createElement(Reveal, null, /*#__PURE__*/React.createElement("h2", {
    className: "gx-h2",
    style: {
      margin: 0,
      textAlign: "center"
    }
  }, t.testimonials.title)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 24,
      maxWidth: 900,
      marginInline: "auto",
      width: "100%"
    }
  }, t.testimonials.items.map((x, i) => /*#__PURE__*/React.createElement(Reveal, {
    key: i,
    delay: i * 100
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-card)",
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-lg)",
      boxShadow: "var(--shadow-sm)",
      padding: 28,
      display: "flex",
      flexDirection: "column",
      gap: 18,
      height: "100%",
      boxSizing: "border-box"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: "var(--font-body)",
      fontSize: 15.5,
      lineHeight: 1.75,
      color: "var(--ink-800)"
    }
  }, "\u201C", x.quote, "\u201D"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      marginTop: "auto"
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    initials: x.initials,
    size: 42
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: 14.5,
      color: "var(--text-heading)"
    }
  }, x.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: 13,
      color: "var(--ink-500)"
    }
  }, x.role)))))))));
}
function AppBand({
  t,
  lang
}) {
  const [done, setDone] = React.useState(false);
  return /*#__PURE__*/React.createElement("section", {
    id: "instructors",
    style: {
      background: "var(--ink-900)",
      padding: "88px 0",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      background: "radial-gradient(700px 400px at 25% 80%, rgba(79,124,255,0.22), transparent 60%)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "gx-container",
    style: {
      position: "relative",
      display: "grid",
      gridTemplateColumns: "1fr auto",
      gap: 56,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 18,
      alignItems: "flex-start"
    }
  }, /*#__PURE__*/React.createElement(Reveal, null, /*#__PURE__*/React.createElement(Badge, {
    tone: "warning"
  }, t.app.badge)), /*#__PURE__*/React.createElement(Reveal, {
    delay: 80
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontWeight: 800,
      fontSize: "clamp(28px,3.2vw,40px)",
      color: "#fff",
      textWrap: "balance"
    }
  }, t.app.title)), /*#__PURE__*/React.createElement(Reveal, {
    delay: 160
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: "var(--font-body)",
      fontSize: 16.5,
      lineHeight: 1.7,
      color: "rgba(255,255,255,0.7)",
      maxWidth: 480
    }
  }, t.app.desc)), /*#__PURE__*/React.createElement(Reveal, {
    delay: 240
  }, done ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: 15,
      color: "var(--orange-200)"
    }
  }, t.app.done) : /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      setDone(true);
    },
    style: {
      display: "flex",
      gap: 10,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Input, {
    type: "email",
    required: true,
    placeholder: t.app.inputPlaceholder,
    inputStyle: {
      background: "rgba(255,255,255,0.08)",
      border: "1px solid rgba(255,255,255,0.2)",
      color: "#fff"
    }
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    type: "submit",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "bell",
      size: 15
    })
  }, t.app.button))), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 12,
      color: "rgba(255,255,255,0.4)"
    }
  }, t.app.platforms)), /*#__PURE__*/React.createElement(Reveal, {
    delay: 150
  }, /*#__PURE__*/React.createElement(PhoneMock, {
    lang: lang
  }))));
}
function Footer({
  t
}) {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: "var(--ink-900)",
      borderTop: "1px solid rgba(255,255,255,0.08)",
      padding: "56px 0 32px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "gx-container",
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1.4fr repeat(3,1fr)",
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12,
      alignItems: "flex-start"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 9
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-bird.png",
    alt: "",
    style: {
      height: 30,
      display: "block"
    }
  }), /*#__PURE__*/React.createElement(Wordmark, {
    size: 19,
    inverse: true
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: 14,
      color: "rgba(255,255,255,0.55)"
    }
  }, t.footer.tagline)), t.footer.columns.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.title,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: 13.5,
      color: "rgba(255,255,255,0.85)"
    }
  }, c.title), c.links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#top",
    style: {
      fontFamily: "var(--font-body)",
      fontSize: 13.5,
      color: "rgba(255,255,255,0.5)",
      textDecoration: "none"
    }
  }, l))))), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: 12.5,
      color: "rgba(255,255,255,0.35)",
      borderTop: "1px solid rgba(255,255,255,0.08)",
      paddingTop: 20
    }
  }, t.footer.copyright)));
}
Object.assign(window, {
  Nav,
  Hero,
  Features,
  Courses,
  Testimonials,
  AppBand,
  Footer
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/sections.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/visuals.jsx
try { (() => {
// Feature mock visuals — blue palette adaptations of repo landing/visuals.jsx
const {
  Badge: VBadge,
  ProgressBar: VProgress,
  Icon: VIcon,
  Wordmark: VWordmark
} = window.GradexDesignSystem_f4d388;
function StreamMock() {
  return /*#__PURE__*/React.createElement("div", {
    dir: "ltr",
    style: {
      background: "var(--ink-900)",
      borderRadius: "var(--radius-lg)",
      aspectRatio: "16/10",
      position: "relative",
      overflow: "hidden",
      boxShadow: "var(--shadow-lg)",
      width: "100%"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      background: "linear-gradient(135deg, rgba(79,124,255,0.35), rgba(30,78,216,0.1) 60%)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 14,
      insetInlineEnd: 16,
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      color: "rgba(255,255,255,0.45)",
      letterSpacing: "0.04em"
    }
  }, "user#8842 \xB7 session 21:04"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      width: 64,
      height: 64,
      borderRadius: "50%",
      background: "rgba(255,255,255,0.92)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "var(--blue-600)",
      boxShadow: "var(--shadow-brand)"
    }
  }, /*#__PURE__*/React.createElement(VIcon, {
    name: "play",
    size: 26,
    style: {
      marginLeft: 3,
      fill: "currentColor"
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      insetInline: 16,
      bottom: 14,
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 5,
      borderRadius: 999,
      background: "rgba(255,255,255,0.2)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "64%",
      height: "100%",
      borderRadius: 999,
      background: "var(--blue-300)"
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      color: "rgba(255,255,255,0.75)"
    }
  }, "1080p \xB7 auto")));
}
function NotesMock({
  lang
}) {
  const en = lang !== "ar";
  const line = (w, strong, k) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      height: strong ? 10 : 8,
      width: w,
      borderRadius: 999,
      background: strong ? "var(--blue-200)" : "var(--ink-100)"
    }
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      width: "100%",
      maxWidth: 440,
      marginInline: "auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      transform: "rotate(3deg) translateY(10px)",
      background: "var(--surface-card)",
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-lg)",
      boxShadow: "var(--shadow-sm)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      background: "var(--surface-card)",
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-lg)",
      boxShadow: "var(--shadow-md)",
      padding: 24,
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: 17,
      color: "var(--text-heading)"
    }
  }, en ? "Chapter 4 — Trees" : "الفصل 4 — الأشجار"), /*#__PURE__*/React.createElement(VBadge, {
    tone: "brand"
  }, en ? "6 pages" : "6 صفحات")), line("82%", true, 1), line("95%", false, 2), line("70%", false, 3), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 12.5,
      color: "var(--blue-600)",
      background: "var(--blue-50)",
      border: "1px solid var(--blue-100)",
      borderRadius: "var(--radius-sm)",
      padding: "10px 14px",
      direction: "ltr",
      textAlign: "left"
    }
  }, "height(node) = 1 + max(h(L), h(R))"), line("88%", false, 4), line("58%", false, 5)));
}
function QuizMock({
  lang
}) {
  const en = lang !== "ar";
  const opts = [{
    t: "O(n)",
    ok: false
  }, {
    t: "O(log n)",
    ok: true
  }, {
    t: "O(n log n)",
    ok: false
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-card)",
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-lg)",
      boxShadow: "var(--shadow-md)",
      padding: 24,
      width: "100%",
      maxWidth: 440,
      marginInline: "auto",
      display: "flex",
      flexDirection: "column",
      gap: 16,
      boxSizing: "border-box"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: 13,
      color: "var(--text-muted)",
      letterSpacing: "0.06em",
      textTransform: "uppercase"
    }
  }, en ? "Question 3 of 5" : "السؤال 3 من 5"), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 96
    }
  }, /*#__PURE__*/React.createElement(VProgress, {
    value: 60,
    height: 6
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: 17,
      color: "var(--text-heading)",
      lineHeight: 1.4
    }
  }, en ? "What is the time complexity of binary search?" : "ما التعقيد الزمني للبحث الثنائي؟"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, opts.map((o, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      padding: "11px 16px",
      borderRadius: "var(--radius-md)",
      border: o.ok ? "1px solid var(--blue-500)" : "1px solid var(--border-default)",
      background: o.ok ? "var(--blue-50)" : "var(--surface-card)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      borderRadius: "50%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      border: o.ok ? "none" : "2px solid var(--ink-300)",
      background: o.ok ? "var(--blue-500)" : "transparent",
      color: "#fff",
      boxSizing: "border-box"
    }
  }, o.ok && /*#__PURE__*/React.createElement(VIcon, {
    name: "check",
    size: 12
  })), /*#__PURE__*/React.createElement("span", {
    dir: "ltr",
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 14,
      color: o.ok ? "var(--blue-600)" : "var(--text-body)",
      fontWeight: o.ok ? 600 : 400
    }
  }, o.t)))));
}
function PhoneMock({
  lang
}) {
  const en = lang !== "ar";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 232,
      borderRadius: 36,
      background: "var(--ink-800)",
      padding: 10,
      boxShadow: "var(--shadow-lg)",
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: 28,
      background: "var(--surface-page)",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 26,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 64,
      height: 7,
      borderRadius: 999,
      background: "var(--ink-200)"
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "10px 14px 18px",
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(VWordmark, {
    size: 16
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--gradient-brand)",
      borderRadius: 12,
      padding: "12px 12px 10px",
      color: "#fff"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 9,
      opacity: 0.85,
      direction: "ltr",
      textAlign: "start"
    }
  }, "CS 305"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: 12.5,
      marginTop: 2
    }
  }, en ? "Continue studying" : "واصل الدراسة"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8,
      height: 4,
      borderRadius: 999,
      background: "rgba(255,255,255,0.25)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "72%",
      height: "100%",
      borderRadius: 999,
      background: "#fff"
    }
  }))), [1, 2].map(i => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      background: "var(--surface-card)",
      border: "1px solid var(--border-default)",
      borderRadius: 12,
      padding: 10,
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 26,
      height: 26,
      borderRadius: 8,
      background: "var(--blue-50)",
      color: "var(--blue-600)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement(VIcon, {
    name: i === 1 ? "play" : "fileText",
    size: 13
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 7,
      width: "75%",
      borderRadius: 999,
      background: "var(--ink-200)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 6,
      width: "45%",
      borderRadius: 999,
      background: "var(--ink-100)"
    }
  })))))));
}
Object.assign(window, {
  StreamMock,
  NotesMock,
  QuizMock,
  PhoneMock
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/visuals.jsx", error: String((e && e.message) || e) }); }

__ds_ns.BirdMark = __ds_scope.BirdMark;

__ds_ns.CircleSketch = __ds_scope.CircleSketch;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Reveal = __ds_scope.Reveal;

__ds_ns.Scribble = __ds_scope.Scribble;

__ds_ns.Wordmark = __ds_scope.Wordmark;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.CourseCard = __ds_scope.CourseCard;

__ds_ns.ProgressBar = __ds_scope.ProgressBar;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

})();
